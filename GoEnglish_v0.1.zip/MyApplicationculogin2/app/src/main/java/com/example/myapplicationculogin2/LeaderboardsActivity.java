package com.example.myapplicationculogin2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;

public class LeaderboardsActivity extends AppCompatActivity {

    Button homeButton;
    ListView leaderboardList;
    private FirebaseFirestore db;
    private ArrayList<String> listItems;
    private ArrayAdapter<String> adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards);

        homeButton = findViewById(R.id.homeButton);
        leaderboardList = findViewById(R.id.leaderboardList);

        db = FirebaseFirestore.getInstance();

        listItems = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItems);
        leaderboardList.setAdapter(adapter);

        homeButton.setOnClickListener(v -> navigateToHome());

        fetchLeaderboardData();
    }

    private void fetchLeaderboardData() {
        db.collection("score")
                .orderBy("score", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()) {
                            QuerySnapshot querySnapshot = task.getResult();
                            if (querySnapshot != null) {
                                for (QueryDocumentSnapshot document : querySnapshot) {
                                    String email = document.getId();
                                    Long score = document.getLong("score");

                                    if (score != null) {
                                        String username;
                                        if (email != null && email.contains("@")) {
                                            username = email.split("@")[0];
                                        } else {
                                            username = email;
                                        }
                                        listItems.add(username + " - " + score);
                                    }
                                }
                                adapter.notifyDataSetChanged();
                            }
                        } else {
                            Log.w("LeaderboardsActivity", "Error getting documents.", task.getException());
                            Toast.makeText(LeaderboardsActivity.this, "Error loading leaderboard", Toast.LENGTH_SHORT).show();
                        }
                    }
                });
    }

    private void navigateToHome() {
        Intent intent = new Intent(LeaderboardsActivity.this, UserActivity.class);
        startActivity(intent);
        finish();
    }
}
