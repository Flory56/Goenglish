package com.example.myapplicationculogin2;

import static android.content.ContentValues.TAG;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class TestsActivity extends AppCompatActivity {

    Button returnToUserButton, submitButton;
    LinearLayout questionsLayout;

    String[] questions = {
            "1.Choose the correct tense for: I ___ to the store.",
            "2.Choose the correct tense for: She ___ a book right now.",
            "3.Choose the correct tense for: They ___ their homework.",
            "4.Choose the correct tense for: We ___ a movie last night.",
            "5.Choose the correct tense for: He ___ here every day.",
            "6.Choose the correct tense for: I ___ eating lunch when you called.",
            "7.Choose the correct tense for: She ___ her keys yesterday.",
            "8.Choose the correct tense for: They ___ to the park tomorrow.",
            "9.Choose the correct tense for: We ___ waiting for an hour.",
            "10.Choose the correct tense for: I ___ this book three times.",
            "11.Choose the correct tense for: He ___ the game yesterday.",
            "12.Choose the correct tense for: She ___ a cake right now.",
            "13.Choose the correct tense for: We ___ swimming every summer.",
            "14.Choose the correct tense for: I have ___ my homework already.",
            "15.Choose the correct tense for: They ___ to the museum tomorrow."
    };

    String[][] options = {
            {"went", "go", "going"},
            {"is reading", "reads", "read"},
            {"did", "do", "doing"},
            {"watched", "watch", "watching"},
            {"comes", "came", "coming"},
            {"is", "am", "was"},
            {"lost", "loses", "losing"},
            {"will go", "goes", "going"},
            {"have been", "were", "are"},
            {"have read", "read", "reading"},
            {"had played", "have played", "played"},
            {"is baking", "bakes", "baked"},
            {"gone", "going", "go"},
            {"do", "done", "doing"},
            {"go", "will go", "went"}
    };

    String[] correctAnswers = {
            "go", "is reading", "did", "watched", "comes", "was", "lost", "will go",
            "have been", "have read", "played", "is baking", "go", "done", "will go"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tests);

        returnToUserButton = findViewById(R.id.btnReturnToUser);
        submitButton = findViewById(R.id.submitButton);
        questionsLayout = findViewById(R.id.questionsLayout);

        for (int i = 0; i < questions.length; i++) {
            addQuestion(i);
        }

        returnToUserButton.setOnClickListener(view -> {
            Intent intent = new Intent(TestsActivity.this, UserActivity.class);
            startActivity(intent);
            finish();
        });

        submitButton.setOnClickListener(v -> checkAnswers());
    }

    private void addQuestion(int index) {
        LinearLayout questionContainer = new LinearLayout(this);
        questionContainer.setOrientation(LinearLayout.VERTICAL);
        questionContainer.setPadding(20, 20, 20, 20);
        questionContainer.setBackground(getRoundedCornerDrawable());
        questionContainer.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView questionText = new TextView(this);
        questionText.setText(questions[index]);
        questionText.setTextSize(18);
        questionText.setPadding(10, 10, 10, 10);

        RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setOrientation(RadioGroup.VERTICAL);

        for (String option : options[index]) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(option);
            radioGroup.addView(radioButton);
        }

        questionContainer.addView(questionText);
        questionContainer.addView(radioGroup);

        questionsLayout.addView(questionContainer);

        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                20
        ));

        questionsLayout.addView(space);
    }

    private GradientDrawable getRoundedCornerDrawable() {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(20);
        shape.setColor(Color.WHITE);
        shape.setStroke(3, Color.GRAY);
        return shape;
    }

    private void checkAnswers() {
        int score = 0;

        for (int i = 0; i < questions.length; i++) {
            RadioGroup radioGroup = (RadioGroup) ((LinearLayout) questionsLayout.getChildAt(i * 2)).getChildAt(1);
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedRadioButton = findViewById(selectedId);
                if (selectedRadioButton.getText().toString().equals(correctAnswers[i])) {
                    score++;
                }
            }
        }

        Toast.makeText(this, "You scored " + score + " out of " + questions.length, Toast.LENGTH_LONG).show();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null && currentUser.getEmail() != null) {
            String userEmail = currentUser.getEmail();

            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Map<String, Object> scoreData = new HashMap<>();
            scoreData.put("score", score);
            scoreData.put("timestamp", System.currentTimeMillis());


            db.collection("score").document(userEmail).set(scoreData)
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Score saved for " + userEmail, Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to save score: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });

        } else {
            Toast.makeText(this, "User email not found. Score not saved.", Toast.LENGTH_SHORT).show();
        }
    }

}
