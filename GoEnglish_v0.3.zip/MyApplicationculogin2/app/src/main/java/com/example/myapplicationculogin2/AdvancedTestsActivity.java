package com.example.myapplicationculogin2;

import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.HashMap;
import java.util.Map;

public class AdvancedTestsActivity extends AppCompatActivity {

    Button returnToUserButton, submitButton;
    LinearLayout questionsLayout;

    String[] questions = {
            "1. Choose the correct form: By next year, I ___ finished the project.",
            "2. She said that she ___ already seen the movie.",
            "3. If I ___ you, I would take the job.",
            "4. They ___ the house when the storm started.",
            "5. I wish I ___ more time to study.",
            "6. He ___ working here since 2015.",
            "7. The cake ___ baked when I arrived.",
            "8. We ___ dinner by 8 PM tomorrow.",
            "9. She ___ in Paris for three years before moving.",
            "10. If it ___, we will stay home."
    };

    String[][] options = {
            {"will have", "will has", "will had"},
            {"had", "has", "have"},
            {"was", "were", "are"},
            {"were painting", "painted", "had painted"},
            {"have", "had", "has"},
            {"is", "has been", "was"},
            {"had been", "was", "has been"},
            {"will have finished", "will finished", "will have finish"},
            {"has lived", "had lived", "have lived"},
            {"rains", "rain", "will rain"}
    };

    String[] correctAnswers = {
            "will have", "has", "were", "were painting", "had", "has been", "was", "will have finished", "had lived", "rains"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_advanced_tests);

        returnToUserButton = findViewById(R.id.btnReturnToUser);
        submitButton = findViewById(R.id.submitButton);
        questionsLayout = findViewById(R.id.questionsLayout);

        for (int i = 0; i < questions.length; i++) {
            addQuestion(i);
        }

        returnToUserButton.setOnClickListener(view -> {
            Intent intent = new Intent(AdvancedTestsActivity.this, UserActivity.class);
            startActivity(intent);
            finish();
        });

        submitButton.setOnClickListener(v -> checkAnswers());
    }

    private void addQuestion(int index) {
        LinearLayout questionContainer = new LinearLayout(this);
        questionContainer.setOrientation(LinearLayout.VERTICAL);
        questionContainer.setPadding(20, 20, 20, 20);
        questionContainer.setBackground(getRoundedCornerDrawable());
        questionContainer.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        ));

        TextView questionText = new TextView(this);
        questionText.setText(questions[index]);
        questionText.setTextSize(18);
        questionText.setPadding(10, 10, 10, 10);

        RadioGroup radioGroup = new RadioGroup(this);
        radioGroup.setOrientation(RadioGroup.VERTICAL);

        for (String option : options[index]) {
            RadioButton radioButton = new RadioButton(this);
            radioButton.setText(option);
            radioGroup.addView(radioButton);
        }

        questionContainer.addView(questionText);
        questionContainer.addView(radioGroup);

        questionsLayout.addView(questionContainer);


        View space = new View(this);
        space.setLayoutParams(new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                20
        ));

        questionsLayout.addView(space);
    }

    private GradientDrawable getRoundedCornerDrawable() {
        GradientDrawable shape = new GradientDrawable();
        shape.setShape(GradientDrawable.RECTANGLE);
        shape.setCornerRadius(20);
        shape.setColor(Color.WHITE);
        shape.setStroke(3, Color.GRAY);
        return shape;
    }

    private void checkAnswers() {
        int score = 0;

        for (int i = 0; i < questions.length; i++) {

            RadioGroup radioGroup = (RadioGroup) ((LinearLayout) questionsLayout.getChildAt(i * 2)).getChildAt(1);
            int selectedId = radioGroup.getCheckedRadioButtonId();
            if (selectedId != -1) {
                RadioButton selectedRadioButton = findViewById(selectedId);
                if (selectedRadioButton.getText().toString().equals(correctAnswers[i])) {
                    score++;
                }
            }
        }

        Toast.makeText(this, "You scored " + score + " out of " + questions.length, Toast.LENGTH_LONG).show();

        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null && currentUser.getEmail() != null) {
            String userEmail = currentUser.getEmail();

            FirebaseFirestore db = FirebaseFirestore.getInstance();
            Map<String, Object> scoreData = new HashMap<>();
            scoreData.put("advanced_scores", score);
            scoreData.put("timestamp", System.currentTimeMillis());

            db.collection("advanced_scores").document(userEmail).set(scoreData)
                    .addOnSuccessListener(unused -> {
                        Toast.makeText(this, "Score saved for " + userEmail, Toast.LENGTH_SHORT).show();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to save score: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });

        } else {
            Toast.makeText(this, "User email not found. Score not saved.", Toast.LENGTH_SHORT).show();
        }
    }
}
