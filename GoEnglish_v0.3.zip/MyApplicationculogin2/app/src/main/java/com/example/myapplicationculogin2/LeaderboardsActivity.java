package com.example.myapplicationculogin2;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ListView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class LeaderboardsActivity extends AppCompatActivity {

    Button homeButton;
    ListView leaderboardList;
    private FirebaseFirestore db;
    private ArrayList<String> listItems;
    private ArrayAdapter<String> adapter;

    private Map<String, Long> userScores = new HashMap<>();
    private int collectionsLoaded = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_leaderboards);

        homeButton = findViewById(R.id.homeButton);
        leaderboardList = findViewById(R.id.leaderboardList);

        db = FirebaseFirestore.getInstance();

        listItems = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, listItems);
        leaderboardList.setAdapter(adapter);

        homeButton.setOnClickListener(v -> navigateToHome());

        fetchScoresFromCollections();
    }

    private void fetchScoresFromCollections() {
        fetchScoresFromCollection("advanced_score", "advanced_score");
        fetchScoresFromCollection("advanced_scores", "advanced_scores");
    }

    private void fetchScoresFromCollection(String collectionName, String fieldName) {
        db.collection(collectionName)
                .get()
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        QuerySnapshot querySnapshot = task.getResult();
                        if (querySnapshot != null) {
                            for (QueryDocumentSnapshot document : querySnapshot) {
                                String email = document.getId();
                                Long score = document.getLong(fieldName);
                                if (score != null) {
                                    long currentScore = userScores.getOrDefault(email, 0L);
                                    userScores.put(email, currentScore + score);
                                }
                            }
                        }
                    } else {
                        Log.w("LeaderboardsActivity", "Error getting documents from " + collectionName, task.getException());
                        Toast.makeText(LeaderboardsActivity.this, "Error loading from " + collectionName, Toast.LENGTH_SHORT).show();
                    }

                    collectionsLoaded++;
                    if (collectionsLoaded == 2) {
                        saveToScoreCollection();
                        updateLeaderboard();
                    }
                });
    }

    private void saveToScoreCollection() {
        for (Map.Entry<String, Long> entry : userScores.entrySet()) {
            String email = entry.getKey();
            long totalScore = entry.getValue();

            Map<String, Object> data = new HashMap<>();
            data.put("total_score", totalScore);
            data.put("timestamp", System.currentTimeMillis());

            db.collection("score").document(email).set(data)
                    .addOnSuccessListener(unused -> Log.d("LeaderboardsActivity", "Saved total score for " + email))
                    .addOnFailureListener(e -> Log.w("LeaderboardsActivity", "Failed to save score for " + email, e));
        }
    }

    private void updateLeaderboard() {
        listItems.clear();

        userScores.entrySet().stream()
                .sorted((e1, e2) -> Long.compare(e2.getValue(), e1.getValue()))
                .forEach(entry -> {
                    String email = entry.getKey();
                    Long score = entry.getValue();
                    String username = (email != null && email.contains("@")) ? email.split("@")[0] : email;
                    listItems.add(username + " - " + score);
                });

        adapter.notifyDataSetChanged();
    }

    private void navigateToHome() {
        Intent intent = new Intent(LeaderboardsActivity.this, UserActivity.class);
        startActivity(intent);
        finish();
    }
}
