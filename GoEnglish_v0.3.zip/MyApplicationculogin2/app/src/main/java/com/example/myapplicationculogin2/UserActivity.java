package com.example.myapplicationculogin2;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class UserActivity extends AppCompatActivity {

    Button btnLogOut, goToVerbtensesButton, goToTestsActivityButton, goToTest1Button, goToLeaderboardsButton;
    TextView txtUser;
    FirebaseAuth firebaseAuth;
    FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user);

        firebaseAuth = FirebaseAuth.getInstance();

        btnLogOut = findViewById(R.id.button2);
        txtUser = findViewById(R.id.textView3);
        goToVerbtensesButton = findViewById(R.id.goToVerbtensesButton);
        goToTestsActivityButton = findViewById(R.id.goToTestsActivityButton); // buton Test 2 (exemplu)
        goToTest1Button = findViewById(R.id.goToTest1Button); // buton Test 1
        goToLeaderboardsButton = findViewById(R.id.button);

        user = firebaseAuth.getCurrentUser();

        if (user == null) {
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finish();
        } else {
            String email = user.getEmail();
            if (email != null && email.contains("@")) {
                String username = email.split("@")[0];
                txtUser.setText(username);
            } else {
                txtUser.setText("User");
            }
        }

        btnLogOut.setOnClickListener(view -> {
            FirebaseAuth.getInstance().signOut();
            Intent intent = new Intent(getApplicationContext(), LoginActivity.class);
            startActivity(intent);
            finish();
        });

        goToVerbtensesButton.setOnClickListener(view -> navigateToVerbtenses());
        goToTestsActivityButton.setOnClickListener(view -> navigateToAdvancedTestsActivity()); // al doilea test
        goToTest1Button.setOnClickListener(view -> navigateToTestsActivity()); // primul test
        goToLeaderboardsButton.setOnClickListener(view -> navigateToLeaderboards());
    }

    private void navigateToVerbtenses() {
        Intent intent = new Intent(UserActivity.this, VerbTenses.class);
        startActivity(intent);
    }

    private void navigateToTestsActivity() {
        Intent intent = new Intent(UserActivity.this, TestsActivity.class); // Test 1
        startActivity(intent);
    }

    private void navigateToAdvancedTestsActivity() {
        Intent intent = new Intent(UserActivity.this, AdvancedTestsActivity.class); // Test 2 (mai avansat)
        startActivity(intent);
    }

    private void navigateToLeaderboards() {
        Intent intent = new Intent(UserActivity.this, LeaderboardsActivity.class);
        startActivity(intent);
    }
}
