package com.example.myapplicationculogin2;

import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.text.Html;
import android.text.Spanned;
import android.widget.Button;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

public class VerbTenses extends AppCompatActivity {

    Button returnToUserButton;
    TextView textViewTenses;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_verb_tenses);

        returnToUserButton = findViewById(R.id.btnHome);
        textViewTenses = findViewById(R.id.textViewTenses);

        String tenseList = "<b>• Present Simple</b><br>" +
                "<b>How to Form:</b> Base form (infinitive) for all persons except 3rd person singular (add \"s\" or \"es\" for he, she, it).<br>" +
                "<b>Use:</b> habits, facts, general truths<br>" +
                "<b>Markers:</b> always, usually, often, sometimes, every day/week/year, on Mondays, never<br>" +
                "<b>Example:</b> I speak, You speak, He/She/It speaks<br><br>" +

                "<b>• Present Continuous</b><br>" +
                "<b>How to Form:</b> am/are/is + verb + ing<br>" +
                "<b>Use:</b> actions happening now or around now<br>" +
                "<b>Markers:</b> now, at the moment, right now, currently, these days, today, this week<br>" +
                "<b>Example:</b> I’m speaking, You’re speaking, He’s speaking<br><br>" +

                "<b>• Present Perfect</b><br>" +
                "<b>How to Form:</b> have/has + past participle<br>" +
                "<b>Use:</b> actions with relevance to the present<br>" +
                "<b>Markers:</b> just, already, yet, ever, never, so far, recently, since, for<br>" +
                "<b>Example:</b> I’ve spoken, You’ve spoken, He’s spoken<br><br>" +

                "<b>• Present Perfect Continuous</b><br>" +
                "<b>How to Form:</b> have/has + been + verb + ing<br>" +
                "<b>Use:</b> actions that started in the past and continue now<br>" +
                "<b>Markers:</b> for, since, all day, how long, lately, recently<br>" +
                "<b>Example:</b> I’ve been speaking, You’ve been speaking, He’s been speaking<br><br>" +

                "<b>• Past Simple</b><br>" +
                "<b>How to Form:</b> Verb + ed (regular) or 2nd form (irregular)<br>" +
                "<b>Use:</b> completed actions in the past<br>" +
                "<b>Markers:</b> yesterday, last week/month/year, in 1990, ago, when I was a child, then<br>" +
                "<b>Example:</b> I spoke, You spoke, He/She/It spoke<br><br>" +

                "<b>• Past Continuous</b><br>" +
                "<b>How to Form:</b> was/were + verb + ing<br>" +
                "<b>Use:</b> actions in progress at a specific time in the past<br>" +
                "<b>Markers:</b> while, when, as, at 5 p.m. yesterday, all night, during<br>" +
                "<b>Example:</b> I was speaking, You were speaking, He was speaking<br><br>" +

                "<b>• Past Perfect</b><br>" +
                "<b>How to Form:</b> had + past participle<br>" +
                "<b>Use:</b> actions completed before a point in the past<br>" +
                "<b>Markers:</b> already, before, by the time, after, when, until then<br>" +
                "<b>Example:</b> I’d spoken, You’d spoken, He’d spoken<br><br>" +

                "<b>• Past Perfect Continuous</b><br>" +
                "<b>How to Form:</b> had + been + verb + ing<br>" +
                "<b>Use:</b> ongoing past actions before another past event<br>" +
                "<b>Markers:</b> for, since, before, until, how long, all day/week/month<br>" +
                "<b>Example:</b> I’d been speaking, You’d been speaking, He’d been speaking<br><br>" +

                "<b>• Future Simple</b><br>" +
                "<b>How to Form:</b> will + base form of verb<br>" +
                "<b>Use:</b> decisions, predictions, promises<br>" +
                "<b>Markers:</b> tomorrow, next week, in 2025, soon, later, I think / I hope<br>" +
                "<b>Example:</b> I’ll speak, You’ll speak, He’ll speak<br><br>" +

                "<b>• Future Continuous</b><br>" +
                "<b>How to Form:</b> will + be + verb + ing<br>" +
                "<b>Use:</b> action in progress at a specific future time<br>" +
                "<b>Markers:</b> this time tomorrow, next week at 5, in the morning, all day tomorrow<br>" +
                "<b>Example:</b> I’ll be speaking, You’ll be speaking, He’ll be speaking<br><br>" +

                "<b>• Future Perfect</b><br>" +
                "<b>How to Form:</b> will + have + past participle<br>" +
                "<b>Use:</b> action completed before a point in the future<br>" +
                "<b>Markers:</b> by next year, by 6 p.m., before, in two weeks<br>" +
                "<b>Example:</b> I’ll have spoken, You’ll have spoken, He’ll have spoken<br><br>" +

                "<b>• Future Perfect Continuous</b><br>" +
                "<b>How to Form:</b> will + have + been + verb + ing<br>" +
                "<b>Use:</b> ongoing action up to a future point<br>" +
                "<b>Markers:</b> for, since, by the time, how long (in future context)<br>" +
                "<b>Example:</b> I’ll have been speaking, You’ll have been speaking, He’ll have been speaking";

        Spanned formattedText;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.N) {
            formattedText = Html.fromHtml(tenseList, Html.FROM_HTML_MODE_LEGACY);
        } else {
            formattedText = Html.fromHtml(tenseList);
        }

        textViewTenses.setText(formattedText);

        returnToUserButton.setOnClickListener(view -> navigateBackToUser());
    }

    private void navigateBackToUser() {
        Intent intent = new Intent(VerbTenses.this, UserActivity.class);
        startActivity(intent);
        finish();
    }
}
